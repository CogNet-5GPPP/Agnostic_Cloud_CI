from kafka import KafkaConsumer
from kafka import KafkaProducer
from kafka.errors import KafkaError





consumer = KafkaConsumer('metrics',
                         bootstrap_servers=["monasca:9092"])

producer = KafkaProducer(bootstrap_servers=["kafka:9092"])


for message in consumer:
	
        future = producer.send('metrics',message.value)

