from kafka import KafkaConsumer
from kafka import KafkaProducer
from kafka.errors import KafkaError
import json
import os
import shutil
import os.path
import requests
import signal
from requests.auth import HTTPBasicAuth
import json
import syslog
import logging
import logging.handlers



my_logger = logging.getLogger('policy_engine_builder')
my_logger.setLevel(logging.INFO)
if not len(my_logger.handlers):
	handler = logging.handlers.SysLogHandler(address = '/dev/log', facility='local1')
	handler.setFormatter(logging.Formatter('%(name)s %(message)s'))
	my_logger.addHandler(handler)

policy_engine_home="/home/cognet/policy_manager/"



# To consume latest messages and auto-commit offsets
consumer = KafkaConsumer('newpolicy',bootstrap_servers=["kafka:9092"])
my_logger.info("Starting policy engine")
for message in consumer:
		# do something with received messages
	my_logger.info("New incoming policy")
	try:
		json_message = json.loads(message.value)
		my_logger.debug(json_message)
		topic=json_message['supa-policy']['supa-policy-target']['topicName'] #Get topicName
		condition=json_message['supa-policy']['supa-policy-statement']['condition']['condition-name'] #Get condition-name
		buildnametmp="%s_%s" %(topic,condition.lstrip(' '))
		buildname=buildnametmp.lstrip(' ')
		topicfile="%s/topics/%s.json" %(policy_engine_home,buildname)


		with open (topicfile,'w') as outfile: #Write json content to file named topicName
			json.dump(json_message,outfile)
		

		operator_symbol=json_message['supa-policy']['supa-policy-statement']['condition']['condition-operator'] #Get condition-operator 
		operator_threshold=json_message['supa-policy']['supa-policy-statement']['condition']['condition-threshold'] #Get condition-threshold
		action=json_message['supa-policy']['supa-policy-statement']['action']['action-param'] #Get action-param 
		action_host=json_message['supa-policy']['supa-policy-statement']['action']['action-host'] #Get action-host 
		action_string=json.dumps(action) 
		raw_action=action_string.replace('"',r'\"');


		# Multiple events support
		# 
		value_type=""
		value_type1=""
		parse_value_type=""
		events=json_message['supa-policy']['supa-policy-statement']['event']
		condition_name=json_message['supa-policy']['supa-policy-statement']['condition']['condition-name']

		if isinstance(events, list):
			my_logger.info("Multiple events")
			for i in range (0, len(events)-1):
				value_name=json_message['supa-policy']['supa-policy-statement']['event'][i]['event-name'] #Get value-type from each event
				#print "compare %s with %s " %(value_name,condition_name)
				if value_name in condition_name:
					value_type=json_message['supa-policy']['supa-policy-statement']['event'][i]['event-value-type'] #Get value-type from each event
					value_type1=value_type.title()
					parse_value_type="parse%s" %value_type1
					if value_type == "int":
						value_type1="Integer"
		elif isinstance(events, dict):
			my_logger.info("Single element")
			value_name=json_message['supa-policy']['supa-policy-statement']['event']['event-name'] #Get value-type from each event
			if value_name in condition_name:
				value_type=json_message['supa-policy']['supa-policy-statement']['event']['event-value-type'] #Get value-type from each event
				value_type1=value_type.title()
				parse_value_type="parse%s" %value_type1
				if value_type == "int":
					value_type1="Integer"
			else:
				my_logger.error("Not valid condition name")
				break

		else:
			my_logger.error("Not valid")
			break



		#exit()
		#Generate  java class from JSON
		jar_path="%s/jar/%s-jar-with-dependencies.jar" %(policy_engine_home,buildname)
		if  os.path.isfile(jar_path):
			my_logger.warning("file %s exists, stopping, removing and rebuilding"%jar_path)
			log_filename="%s/jar/%s-jar-with-dependencies.jar.log" %(policy_engine_home,buildname)
			destination_filename="%s/jar/%s-jar-with-dependencies.jar" %(policy_engine_home,buildname)
			destination_folder="%s/builds/%s/" %(policy_engine_home,buildname)

			try:
				f = open(log_filename,'r')
				first_line = f.readline()
				my_logger.info("Stopping pid %s"%first_line)
				f.close()
				try:
					os.kill(int(first_line), signal.SIGTERM)
					os.remove(destination_filename)
					shutil.rmtree(destination_folder)
				except OSError as e:
					my_logger.warning("Process was stopped, nothing done")
		
			except OSError as e:
				my_logger.error("Cannot detect pid file, not stopping")
			except IOError as e:
				my_logger.error("Cannot detect pid file, not stopping")


		else:
			my_logger.debug("file %s doesn't exists"%jar_path)

		my_logger.debug("building %s"%buildname)
		commandline="%s/tools/jsonschema2pojo-0.4.29/bin/./jsonschema2pojo --source %s  -D -S -E --target %s/policies/code/%s -p org.cognet.policy -T JSON" %(policy_engine_home,topicfile,policy_engine_home,buildname)
		os.system(commandline);
			#Prepare for building: copy seed kafka client, copy generated java class
		commandline="mkdir -p %s/builds/%s/ ; cp -r %s/seed %s/builds/%s/ ; cp -r %s/policies/code/%s/org/cognet/policy/ %s/builds/%s/seed/src/main/java/org/cognet/ " %(policy_engine_home,buildname,policy_engine_home,policy_engine_home,buildname,policy_engine_home,buildname,policy_engine_home,buildname)
		os.system(commandline);
		if isinstance(events, list):
			commandline="mv %s/builds/%s/seed/src/main/java/org/cognet/kafka/ConsumerMultiple.java %s/builds/%s/seed/src/main/java/org/cognet/kafka/Consumer.java ; rm %s/builds/%s/seed/src/main/java/org/cognet/kafka/ConsumerSingle.java " %(policy_engine_home,buildname,policy_engine_home,buildname,policy_engine_home,buildname)
			os.system(commandline);
		elif isinstance(events, dict):
			commandline="mv %s/builds/%s/seed/src/main/java/org/cognet/kafka/ConsumerSingle.java %s/builds/%s/seed/src/main/java/org/cognet/kafka/Consumer.java ; rm %s/builds/%s/seed/src/main/java/org/cognet/kafka/ConsumerMultiple.java " %(policy_engine_home,buildname,policy_engine_home,buildname,policy_engine_home,buildname)
			os.system(commandline);
		else:
			my_logger.error("No input events, nothing built")
			break;
		#param substition: topicname and action and host to be performed
		consumerfile="%s/builds/%s/seed/src/main/java/org/cognet/kafka/Consumer.java" %(policy_engine_home,buildname)
		actionfile="%s/builds/%s/seed/src/main/java/org/cognet/kafka/Action.java" %(policy_engine_home,buildname)
		pomfile="%s/builds/%s/seed/pom.xml" %(policy_engine_home,buildname)
		f = open(consumerfile,'r')
		filedata = f.read()
		f.close()
		newdata = filedata.replace("topic_name",topic)
		#Generate  java class from JSON
		#commandline="%s/tools/jsonschema2pojo-0.4.29/bin/./jsonschema2pojo --source %s  -D -E --target %s/policies/code/%s -p org.cognet.policy -T JSON" %(policy_engine_home,topicfile,policy_engine_home,buildname)
		#os.system(commandline);
		#Prepare for building: copy seed kafka client, copy generated java class
		#commandline="mkdir -p %s/builds/%s/ ; cp -r %s/seed /home/cognet/policy_manager/builds/%s/ ; cp -r %s/policies/code/%s/org/cognet/policy/ %s/builds/%s/seed/src/main/java/org/cognet/ " %(policy_engine_home,buildname,policy_engine_home,buildname,policy_engine_home,buildname,policy_engine_home,buildname)
		#os.system(commandline);
		#param substition: topicname and action and host to be performed
		
		consumerfile="%s/builds/%s/seed/src/main/java/org/cognet/kafka/Consumer.java" %(policy_engine_home,buildname)
		producerfile="%s/builds/%s/seed/src/main/java/org/cognet/kafka/Producer.java" %(policy_engine_home,buildname)
		actionfile="%s/builds/%s/seed/src/main/java/org/cognet/kafka/Action.java" %(policy_engine_home,buildname)
		pomfile="%s/builds/%s/seed/pom.xml" %(policy_engine_home,buildname)
		f = open(consumerfile,'r')
		filedata = f.read()
		f.close()
		newdata = filedata.replace("topic_name",topic) \
		.replace("operator_symbol",operator_symbol) \
		.replace("operator_threshold",operator_threshold) \
		.replace("build_name",buildname) \
		.replace("action_param",raw_action) \
		.replace("value_Type",value_type) \
		.replace("valueType",value_type1) \
		.replace("parseValueType",parse_value_type) 
		f = open(consumerfile,'w')
		f.write(newdata)
		f.close()
		f = open(consumerfile,'r')
		filedata = f.read()
		f.close()
		newdata = filedata.replace("Class_Action","Producer")
		if not action_host:
			my_logger.info ("Building Kafka messaging service %s"%buildname)
			newdata = filedata.replace("Class_Action","Producer")
		else:
			my_logger.info ("Building REST messaging service %s"%buildname)
			newdata = filedata.replace("Class_Action","Action")
		f = open(consumerfile,'w')
		f.write(newdata)
		f.close()
		f = open(producerfile,'r')
		filedata = f.read()
		f.close()
		newdata = filedata.replace("build_name",buildname) \
		.replace("action_param",raw_action) \
		.replace("topic_name",topic)
		f = open(producerfile,'w')
		f.write(newdata)
		f.close()
		f = open(actionfile,'r')
		filedata = f.read()
		f.close()
		#newdata = filedata.replace("action_param",raw_action) \
		newdata = filedata.replace("action_host",action_host) \
		.replace("build_name",buildname) 
		f = open(actionfile,'w')
		f.write(newdata)
		f.close()
		f = open(pomfile,'r')
		filedata = f.read()
		f.close()
		newdata = filedata.replace("topic_name",buildname)
		f = open(pomfile,'w')
		f.write(newdata)
		f.close()
		my_logger.debug("Building element %s"%buildname)
		#Build using maven
		commandline="cd %s/builds/%s/seed ; mvn clean > /dev/null ; mvn package >/dev/null" %(policy_engine_home,buildname)
		output=os.system(commandline);
		if output == 0:
			my_logger.debug ("Deploying jar %s"%buildname)
			commandline="cp %s/builds/%s/seed/target/%s-jar-with-dependencies.jar %s/jar " %(policy_engine_home,buildname,buildname,policy_engine_home)
			output=os.system(commandline);
			if output == 0:
				my_logger.info ("Deployed %s"%buildname)
				print("Deployed %s"%buildname)
			else:
				my_logger.error("Error deploying jar file %s"%buildname)
				print("Error deploying jar file %s"%buildname)
		else:
			my_logger.error("Error building %s"%buildname)
			print("Error building %s"%buildname)


	except ValueError:
		my_logger.error("No valid incoming policy")
		print("Error: No valid incoming policy")
	
