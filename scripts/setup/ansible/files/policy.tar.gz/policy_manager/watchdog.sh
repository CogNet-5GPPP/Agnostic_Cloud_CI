#!/bin/bash
MONITORDIR="/home/cognet/policy_manager/jar"
logger -p local1.info -t wathdogdaemon "Starting watchdog daemon"
for i in `ls ${MONITORDIR}/*.jar`
	 do 
     echo "existing jar file: $i"
     java -Xmx2048m -jar "$i" >/dev/null &
	 last=`echo $!`

	 ls -l /proc/$last > /dev/null
	   if [ $? -eq 0 ]
            then
            	logger -p local1.info -t wathdogdaemon "jar file: $i launched" # If so, do your thing here!
                echo $last > "$i.log"
                echo "$i.log"
            else
            	logger -p local1.error -t wathdogdaemon "Error launching jar file: $i" # If so, do your thing here!
            fi
done
# -e modify para inotify
inotifywait -m -r -e create --format '%w%f' "${MONITORDIR}" | while read NEWFILE
do
    if [[ "${NEWFILE}" =~ .*jar$ ]];
        then # Does the file end with .jar?
            echo "New jar file: $NEWFILE"
            logger -p local1.info -t wathdogdaemon "New jar file: $NEWFILE" # If so, do your thing here!
            sleep 3
            java -Xmx2048m -jar ${NEWFILE} > /dev/null &
            last=`echo $!`
	 		ls -l /proc/$last > /dev/null
            if [ $? -eq 0 ]
            then
            	logger -p local1.info -t wathdogdaemon "jar file: $NEWFILE launched" # If so, do your thing here!
                echo $last > "${NEWFILE}.log"
                echo "${NEWFILE}.log"
            else
            	logger -p local1.error -t wathdogdaemon "Error launching jar file: $NEWFILE" # If so, do your thing here!
            fi

    fi
        echo "New file named ${NEWFILE}"
        done

