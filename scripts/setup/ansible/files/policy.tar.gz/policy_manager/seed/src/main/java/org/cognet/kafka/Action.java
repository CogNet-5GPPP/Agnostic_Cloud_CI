package org.cognet.kafka;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.entity.StringEntity;
import java.io.File;
import java.io.IOException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;
import java.util.Random;
import java.util.Iterator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.io.IOException;


//send messages to syslog
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class Action {

    public Action()
    {

    }

    public static boolean execute(String JsonRequest)
    {
        HttpClient client = new DefaultHttpClient();
        HttpPost post = new HttpPost("action_host");
         //To be modified by constructor, here will be the action-param
        //String JsonRequest ="action_param";


        String loggerName="build_name";

        Logger log = Logger.getLogger(loggerName);
        HttpResponse  response=null;
       

        try {
	        StringEntity input = new StringEntity(JsonRequest);
            input.setContentType("application/json");
            try {
                post.setEntity(input);
                response = client.execute(post);
                BufferedReader rd = new BufferedReader (new InputStreamReader(response.getEntity().getContent()));
                log.info("Executed REST request to action_host: "+JsonRequest);
                String line = "";
                while ((line = rd.readLine()) != null) {
                    //log.info("Response: "+line);
                }
                
            }
             catch (IOException e) {
                log.error("IO exception error when trying to execute action "+e);
			    //e.printStackTrace();
		    }     
		} catch (UnsupportedEncodingException e) {
			log.error("UnsupportedEncodingException error when trying to execute action");
		}
                 
        
       
        
        return true;
    }
}
