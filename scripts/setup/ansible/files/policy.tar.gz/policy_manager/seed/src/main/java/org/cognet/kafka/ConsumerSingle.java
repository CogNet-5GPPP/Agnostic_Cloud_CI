package org.cognet.kafka;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.util.JSONPObject;
import com.fasterxml.jackson.core.*;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;
import org.HdrHistogram.Histogram;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import java.util.*;




import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Properties;
import java.util.Random;
import java.util.Iterator;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.entity.StringEntity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.io.IOException;


import java.io.File;
import java.io.IOException;
import com.fasterxml.jackson.databind.introspect.*;
import com.fasterxml.jackson.databind.DeserializationFeature;

import com.fasterxml.jackson.annotation.*;

import org.cognet.policy.*;
import java.util.Map;
import com.fasterxml.jackson.core.type.*;

import java.lang.Integer;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;


//send messages to syslog
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;


//java REST request
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.entity.StringEntity;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.commons.codec.binary.Base64;
import org.json.*;




/**
 * This program reads messages from two topics. Messages on "fast-messages" are analyzed
 * to estimate latency (assuming clock synchronization between producer and consumer).
 * <p/>
 * Whenever a message is received on "slow-messages", the stats are dumped.
 */

public class Consumer {

  static       Logger log;
  


  public static List<String> get_odl(String nodename)
  {
            //check opendaylight
    log.info("Check opendayligh for "+nodename+" node");
    List<String> data = new ArrayList<String>();
    HttpClient client = new DefaultHttpClient();
    HttpGet get = new HttpGet("http://odl:8181/restconf/operational/network-topology:network-topology");

    get.addHeader(BasicScheme.authenticate(
      new UsernamePasswordCredentials("admin", "admin"),"UTF-8", false));

    try {
      HttpResponse  response = client.execute(get);
      BufferedReader rd = new BufferedReader (new InputStreamReader(response.getEntity().getContent()));
     // rd = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
      String line = "";
      while ((line = rd.readLine()) != null) {
        JSONObject obj = new JSONObject(line);
        JSONObject networkTopology = obj.getJSONObject("network-topology");
        JSONArray topologyArray = networkTopology.getJSONArray("topology");
        for (int i=0; i<topologyArray.length(); i++) {
          JSONObject item = topologyArray.getJSONObject(i);
          String name = item.getString("topology-id");
          if(name.contains("topology-netconf")==false)
          {
            if(item.has("node"))
            {
              //log.info("There is node");
              JSONArray nodeArray=item.getJSONArray("node");
              for (int j=0; j<nodeArray.length(); j++) 
              {
               JSONObject node=nodeArray.getJSONObject(j);
               log.debug("node found "+node.getString("node-id"));
               /*if(nodename.equals(node.getString("node-id")))
               {
                 log.info("This is my node "+nodename);
               }*/
             }
           }
           if (item.has("link"))
           {
            log.debug("There is link for "+nodename);
            JSONArray linkArray=item.getJSONArray("link");
            for (int j=0; j<linkArray.length(); j++) 
            {
             JSONObject link=linkArray.getJSONObject(j);
                       //log.info("node found "+link.getString("node-id"));
             if(nodename.equals(link.getJSONObject("source").getString("source-node")))
             {
               log.debug("Node link found "+link.getJSONObject("destination").getString("dest-node")+" for "+nodename);
               data.add(link.getJSONObject("destination").getString("dest-node"));
             }
           }
         }
       }
     }
   }
 }
 catch (IOException e) {
  log.error("IOException when checking opendaylight");
} 

log.info("Found "+Arrays.toString(data.toArray())+" connected nodes to "+nodename);
return data;   

}

public static void check_message(String inputJson)
{
  String topic="topic_name";

  String jsonRequest = "action_param";

  JSONObject jsonRequestObject= new JSONObject("{\"action\": "+jsonRequest+"}");
  log.debug("checking message "+inputJson);

  boolean hardcodedResponse=true;



  try {
    JSONObject jsonInput= new JSONObject(inputJson);

    ObjectMapper mapper = new ObjectMapper();
    InputStream stream = new ByteArrayInputStream(inputJson.getBytes(StandardCharsets.UTF_8));


    try
    {
      Map<String, SupaPolicy> obj = mapper.readValue(stream, new TypeReference<Map<String, SupaPolicy>>(){});

      SupaPolicy policy;


      JSONArray actionParamArray=jsonRequestObject.getJSONArray("action");
      JSONObject event=jsonInput.getJSONObject("supa-policy").getJSONObject("supa-policy-statement").getJSONObject("event");

      for (int i=0; i<actionParamArray.length();i++)
      {   
        JSONObject param=actionParamArray.getJSONObject(i);
        if(param.get("param-value") instanceof String)
        {
          String paramValue=param.getString("param-value");
         
         if(paramValue.contains("$event-value"))
          {
            String valueType=event.getString("event-value-type");
            if(valueType.equals("int"))
            {
              Integer value=event.getInt("event-value");
              //Substitution in the JSON
             param.put("param-value","\""+value+"\"");
             hardcodedResponse=false;
            }
            else if (valueType.equals("char"))
            {
              String value=event.getString("event-value");
              //Substitution in the JSON
              param.put("param-value",value);
              hardcodedResponse=false;
            }
            else if (valueType.equals("float"))
            {
              double value=event.getDouble("event-value");
              //Substitution in the JSON
              param.put("param-value",""+value+"");
              hardcodedResponse=false;
            }
          }
         JSONArray paramInstanceNameArray=param.getJSONArray("instanceName");
          for (int j=0;j<paramInstanceNameArray.length();j++)
          {
            String paramInstanceName=paramInstanceNameArray.getString(j);
            if(paramInstanceName.contains("$instanceName"))
            {
              JSONArray valueArray=event.getJSONArray("instanceName");
              param.put("instanceName",valueArray);
              hardcodedResponse=false;
            }
          }
        }
      }

      jsonRequestObject.put("action",actionParamArray);


      for (String key : obj.keySet()) 
      { 
        policy = obj.get(key);
        String topicName=policy.getSupaPolicyTarget().getTopicName();
        String eventName=policy.getSupaPolicyStatement().getEvent().getEventName();
        String conditionName=policy.getSupaPolicyStatement().getCondition().getConditionName();
        String actionName=policy.getSupaPolicyStatement().getAction().getActionName();
        List<String> eventInstanceNameArray=policy.getSupaPolicyStatement().getEvent().getInstanceName();
        
        //Get current action
        org.cognet.policy.Action jsonAction=policy.getSupaPolicyStatement().getAction();

        log.info("New action requested "+actionName);

        if(actionName.toString().contains("reroute"))
        {
          //Checking against opendaylight

          for (int i = 0; i < eventInstanceNameArray.size(); i++) 
          {
            String eventInstanceName=eventInstanceNameArray.get(i);
            if (eventInstanceName.equals("")==false)
            {
              log.debug("Searching for "+eventInstanceNameArray.get(i));


                log.debug("Checking opendaylight instruction");
                List<String> results=get_odl(eventInstanceNameArray.get(i));

                log.debug("Number of results found on opendaylight: "+results.size());
                if(results.size()==0)
                {
                  log.error("not connected nodes detected, waiting for next message");
                  return;
                }

                for (int j=0; j<actionParamArray.length(); j++) {
                  JSONObject actionParam=actionParamArray.getJSONObject(j);
                  log.debug("Old JSON is "+actionParam.toString());

                  actionParam.put("instanceName",results);
                  hardcodedResponse=false;
                  log.debug("New JSON is "+actionParam.toString());
                }

                log.debug("Total new json is "+actionParamArray.toString());
                jsonRequest = actionParamArray.toString();

            }
            else
            {
              log.debug("No event instanceName found");
              if(actionParamArray.toString().contains("<>"))
              {
                log.error("No event instanceName found, nothing done");
                return;
              }
            }
          }
        }
     
        String buildName="build_name";
        if(conditionName.contains(eventName)==false)
        {
          log.warn("Parsed event: "+eventName+" not attached to conditionName: "+conditionName);
          //break;
        }
        else if(!buildName.contains(conditionName))
        {
          log.warn("Bad conditionName");
        }
        else
        {
          log.info("Parsed event: "+eventName+" attached to conditionName: "+conditionName);
          String typeOfValue=policy.getSupaPolicyStatement().getEvent().getEventValueType();
          String valueString=policy.getSupaPolicyStatement().getEvent().getEventValue();
          String valueOperator=policy.getSupaPolicyStatement().getCondition().getConditionOperator();
          try{
	  	value_Type value=valueType.parseValueType(valueString);
          	if(value operator_symbol operator_threshold)
          	{
           	 	log.info("Execute action for input "+value+" operator_symbol "+operator_threshold);
           	 	if(hardcodedResponse==true)
            		{
              			log.info("Hardcoded response");
            		}
            		else
            		{ 
             	 		log.info("Parameter changed response");
            		}
            		Class_Action action = new Class_Action();
            		action.execute(jsonRequestObject.toString());
          	}
          	else
         	{
            		log.info("No Execute action for input "+value+" operator_symbol "+operator_threshold);
          	}
	}
        catch(NumberFormatException ex)
        {
           log.error("Not a valid parseValueType");
        }

        }
      }
  
  } catch (JsonGenerationException e)
  {
   log.error("Error when parsing json "+ e);
 } catch (JsonMappingException e)
 {
   log.error("Error when mapping json "+e);
 } catch (IOException e)
 {
   log.error("IO error "+e);
 }
}
catch (JSONException e)
{
 log.error("Error when parsing json "+e);
}


}


public static void main(String[] args) throws IOException {


  String topic="topic_name";

  String loggerName="build_name";
  log = Logger.getLogger(loggerName);
  BasicConfigurator.configure();
  log.info("Starting");
  Properties props = new Properties();
  //TODO check how many bootstrapservers can be added, check if kafka hostname works
  props.put("bootstrap.servers", "kafka:9092");
  props.put("group.id", "build_name");
  props.put("enable.auto.commit", "false");
  props.put("auto.commit.interval.ms", "100");
  props.put("session.timeout.ms", "10000");
  props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
  props.put("value.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");


  KafkaConsumer<String, String> consumer = new KafkaConsumer<>(props);

  //To be modified by constructor, here will be the topicname
  consumer.subscribe(Arrays.asList(topic));
  //consumer.subscribe(Arrays.asList("metrics", "events"));
  int timeouts = 0;

  //noinspection InfiniteLoopStatement
  while (true) {

            // read records with a short timeout. If we time out, we don't really care.
    ConsumerRecords<String, String> records = consumer.poll(0);
            //System.out.println("nuevo mensaje general");

    for (ConsumerRecord<String, String> record : records) {
      log.debug("Received message");
      switch (record.topic()) {

        //To be modified by constructor, here will be the topicname
        case "topic_name":

        log.debug("Received topic_name message");
        String json_data=record.value();

        check_message(json_data);


        break;
        case "summary-markers":
        break;
        default:
        log.warn("Shouldn't be possible to get message on topic " + record.topic());
      }
    }
  }
}
}
