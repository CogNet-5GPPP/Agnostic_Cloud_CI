package org.cognet.kafka;

import com.google.common.io.Resources;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

//send messages to syslog
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

/**
 * This producer will send a bunch of messages to topic "fast-messages". Every so often,
 * it will send a message to "slow-messages". This shows how messages can be sent to
 * multiple topics. On the receiving end, we will see both kinds of messages but will
 * also see how the two topics aren't really synchronized.
 */
public class Producer {

    public static boolean execute(String JsonRequest) {

        String loggerName="build_name";
        Logger log = Logger.getLogger(loggerName);

        Properties props = new Properties();
        //TODO check how many bootstrapservers can be added, check if kafka hostname works
        props.put("bootstrap.servers", "kafka:9092");
        props.put("acks", "all");
        props.put("retries", "0");
        props.put("batch.size", "16384");
        props.put("auto.commit.interval.ms", "1000");
        props.put("linger.ms", "0");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("block.on.buffer.full", "true");
        KafkaProducer<String, String> producer = new KafkaProducer<>(props);

        try {

            producer.send(new ProducerRecord<String, String>("topic_name",JsonRequest));
                            //String.format("{\"type\":\"marker\", \"t\":%.3f, \"k\":%d}", System.nanoTime() * 1e-9, i)));
            producer.flush();
            log.info("Executed request through kafka : "+ JsonRequest);

        } catch (Throwable throwable) {
            log.error("Throwable error when executing request to kafka");
        } finally {
            log.debug ("Closing kafka connection");
            producer.close();
        }
    return true;
    }

}
