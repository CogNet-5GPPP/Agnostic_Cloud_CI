import requests
from requests.auth import HTTPBasicAuth
import json



def getconnectednodes(source):
	ip="127.0.0.1"
	url="http://%s:8181/restconf/operational/network-topology:network-topology" %ip

	response=requests.get(url, auth=HTTPBasicAuth('admin', 'admin'))

	connectednodes=[]

	if(response.ok):
		jData = json.loads(response.content)
    	topology_list =jData['network-topology']['topology']
    	for topology in topology_list:
    		topology_id=topology['topology-id']
    		urltopology="http://%s:8181/restconf/operational/network-topology:network-topology/topology/%s"%(ip,topology_id)
    		topology_response=requests.get(urltopology, auth=HTTPBasicAuth('admin', 'admin'))
    		if(topology_response.ok):
	#    		print(json.dumps(node_data))
    			#print("OOOOOOOOOOOOOOOOOOOOOOOOOOOOOO")
    			node_data=json.loads(topology_response.content)
    			nodelist=node_data['topology']
    			for element in nodelist:
    				list_of_nodes=element['node']
    				if 'link' in element:
    					list_of_links=element['link']
    					#for node in list_of_nodes:
    					#	node_id=node['node-id']
    					#	print(node_id)
    					conected_nodes=[x for x in list_of_links if (x['destination']['dest-node'] == source )]

    					for connection in conected_nodes:
    						connectednodes.append(connection['source']['source-node'])
    						print(connection['source']['source-node'])
    					#print(len(temp))
    				    				#temp = (x for x in list_of_nodes if (x['node-id'] == source ))
    		else:
    			topology_response.raise_for_status()
    	#print(len(topology_list))
    	#print(json.dumps(topology_list))

	else:
  	# If response code is not ok (200), print the resulting http error code with description
		response.raise_for_status()

	return connectednodes


	
source="openflow:1"


nodes=getconnectednodes(source)

for node in nodes:
	print("I have a node called %s"%node)